public class Main {
    public static void main(String[] args) {
        PizzaFactory pizzaFactory = new PizzaFactory();
        Pizza pizza= null;
        try {
            pizza = pizzaFactory.createPizza(TipPizza.cheesePizza);
        } catch (Exception e) {
            e.printStackTrace();
        }

        pizza.descriere();

        System.out.println("----------------------------------------------");
        AnimalFactory af1, af2;
        af1 = new DogFactory();
        af1.createAnimal();

        af2 = new CatFactory();
        af2.createAnimal();


        GUIFactory g1, g2,g3,g4;
        g1 = new WindowsGUIFactory();
        g1.createButton();

        g2 = new WindowsGUIFactory();
        g2.createMenu();

        g3 = new MacGUIFactory();
        g3.createMenu();
        g4 = new MacGUIFactory();
        g4.createButton();
    }
}