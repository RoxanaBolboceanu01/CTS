public interface AnimalFactory {
    Animal createAnimal();
}
