public class MacMenu implements Menu{
    public MacMenu()
    {
        System.out.println("MacMenu");
    }
}
