public class WindowsMenu implements Menu{
    public WindowsMenu()
    {
        System.out.println("WindowsMenu");
    }
}
