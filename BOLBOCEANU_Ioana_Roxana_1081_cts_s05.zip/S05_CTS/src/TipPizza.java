public enum TipPizza {
    pepperoniPizza,
    cheesePizza
}
