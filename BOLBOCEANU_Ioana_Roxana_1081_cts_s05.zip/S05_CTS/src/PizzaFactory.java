public class PizzaFactory {
    public static Pizza createPizza(TipPizza tipPizza) throws Exception{
        switch (tipPizza) {
            case cheesePizza:
                return new CheesePizza();
            case pepperoniPizza:
                return new PepperoniPizza();
            default:
                throw new Exception("Tipul primit nu este corect");
        }
    }
}
