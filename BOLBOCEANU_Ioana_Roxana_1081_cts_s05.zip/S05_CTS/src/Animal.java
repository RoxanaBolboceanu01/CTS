public interface Animal {

}
