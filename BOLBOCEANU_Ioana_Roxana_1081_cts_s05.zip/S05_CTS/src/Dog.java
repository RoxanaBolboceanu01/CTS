public class Dog implements Animal{
    public Dog()
    {
        System.out.println("Dog");
    }
}
