public interface Pizza {
    void descriere();
}
