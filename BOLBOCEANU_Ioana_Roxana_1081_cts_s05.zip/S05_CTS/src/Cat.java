public class Cat implements Animal {
    public Cat()
    {
        System.out.println("Cat");
    }

}
