public class PepperoniPizza implements Pizza{
    public PepperoniPizza()
    {

    }

    @Override
    public void descriere() {
        System.out.println("Pepperoni Pizza");

    }
}
