public interface Menu {
}
