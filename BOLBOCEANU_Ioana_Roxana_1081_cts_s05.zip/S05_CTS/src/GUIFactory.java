public interface GUIFactory {
    Button createButton();
    Menu createMenu();
}
