public class WindowsButton implements Button{
    public WindowsButton()
    {
        System.out.println("WindowsButton");
    }
}
