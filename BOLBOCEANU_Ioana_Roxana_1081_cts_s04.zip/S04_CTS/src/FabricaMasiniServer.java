public class FabricaMasiniServer {

    //Exemplu Singleton
//O fabrica de masini care implementeaza un sistem centralizat de monitorizare a productiei. Sistemul trebuie sa
//asigure adaugarea si modificarea datelor despre masinile fabricate la nivelul sediului central, intr-un mediu
//securizat (sistemul va exista sub forma unui server dispus in datacenter-ul din HQ). Programatorii trebuie sa
//se asigure ca sistemul nu va putea fi replicat si ca toate datele vor fi manageriate prin intermediul singurului server
//mentionat anterior.

        String nume;
        String tip;
        int cantitate;
        int idUnic;


        private FabricaMasiniServer() {
            this.nume="";
            this.tip="";
            this.cantitate = 0;
            this.idUnic=0;
        }
        private static FabricaMasiniServer instance;
        public static FabricaMasiniServer getInstance() {
            if(instance == null)
            {
                instance = new FabricaMasiniServer();
                return FabricaMasiniServer.instance;
            }
            return FabricaMasiniServer.instance;
        }



}
