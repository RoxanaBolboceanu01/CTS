public class Server {
    int portNr;
    String name;

    private Server() {
        this.portNr=0;
        this.name = "";
    }
    private static Server instance;
    public static Server getInstance() {
        if(instance == null)
        {
            instance = new Server();
            return Server.instance;
        }
        return Server.instance;
    }
    public String showStatus() {
        return "Serverul ruleaza pe portul " + portNr;
    }

}
