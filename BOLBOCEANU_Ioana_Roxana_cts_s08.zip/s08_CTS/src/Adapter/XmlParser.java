package Adapter;

public class XmlParser {
    String xml;


    public void XmlParser(String xml){
        this.xml=xml;
    }
    public void parseXml(String xml){
        System.out.println(xml);
    }
}
