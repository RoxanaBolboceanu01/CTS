package Facade;

public class Rectangle {
    public void draw(){
        System.out.println("Dreptunghiul este desenat");
    }
}
