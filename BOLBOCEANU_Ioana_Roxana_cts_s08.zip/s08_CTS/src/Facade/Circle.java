package Facade;

public class Circle {
    public void draw(){
        System.out.println("Cercul este desenat");
    }
}
