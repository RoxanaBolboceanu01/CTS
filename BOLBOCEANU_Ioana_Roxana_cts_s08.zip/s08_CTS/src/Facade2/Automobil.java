package Facade2;

public interface Automobil {
    public String descriere();

}
