package Exemplu1Factory;

public class Portar implements Jucator{

    public Portar() {
        System.out.println("Aici este un portar");
    }
}
