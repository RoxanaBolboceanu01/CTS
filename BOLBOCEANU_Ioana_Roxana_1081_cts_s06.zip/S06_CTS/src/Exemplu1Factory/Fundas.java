package Exemplu1Factory;

public class Fundas implements Jucator {

    public Fundas() {
        System.out.println("Aici este un fundas");
    }
}
