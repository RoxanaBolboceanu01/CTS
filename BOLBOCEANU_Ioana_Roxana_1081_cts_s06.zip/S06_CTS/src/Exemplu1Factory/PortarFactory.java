package Exemplu1Factory;

public class PortarFactory implements JucatorFactory {
    @Override
    public Jucator creareJucator() {
        return new Portar();
    }
}
