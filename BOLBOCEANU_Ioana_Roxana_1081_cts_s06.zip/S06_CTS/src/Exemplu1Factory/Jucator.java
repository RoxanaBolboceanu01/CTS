package Exemplu1Factory;

public interface Jucator {
}
