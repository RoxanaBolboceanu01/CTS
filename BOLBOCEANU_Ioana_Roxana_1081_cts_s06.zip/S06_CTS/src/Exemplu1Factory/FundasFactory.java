package Exemplu1Factory;

public class FundasFactory implements JucatorFactory{
    @Override
    public Jucator creareJucator() {
        return new Fundas();
    }
}
