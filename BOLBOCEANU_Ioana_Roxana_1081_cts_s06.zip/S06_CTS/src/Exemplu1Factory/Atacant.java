package Exemplu1Factory;

public class Atacant implements Jucator{

    public Atacant() {
        System.out.println("Aici este un atacant");
    }
}
