package Exemplu1Factory;

public class FactoryMain {
    public static void main(String[] args) {
/*. Se dorește implementarea unui modul care să inițializeze în cadrul aplicației obiecte din familia
de obiecte Jucator. Categoriile de jucători existente sunt Portar, Fundas, Atacant. Să se
implementeze acest modul care va crea obiecte din familia Jucator. Modulul trebuie realizat, astfel
încât pentru adăugări de noi tipuri de jucători să nu fie necesare modificări în codul existent. */


        JucatorFactory jucator1,jucator2,jucator3;

        System.out.println("--------------FUNDAS--------------");
        jucator1 = new FundasFactory();
        jucator1.creareJucator();

        System.out.println("--------------ATACANT--------------");
        jucator2 = new AtacantFactory();
        jucator2.creareJucator();

        System.out.println("--------------PORTAR--------------");
        jucator3 = new PortarFactory();
        jucator3.creareJucator();

    }
}
