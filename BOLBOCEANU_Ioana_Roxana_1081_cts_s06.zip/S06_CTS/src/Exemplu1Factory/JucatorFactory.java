package Exemplu1Factory;

public interface JucatorFactory {
    Jucator creareJucator();
}
