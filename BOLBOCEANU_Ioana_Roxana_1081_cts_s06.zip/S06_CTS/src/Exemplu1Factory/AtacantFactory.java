package Exemplu1Factory;

public class AtacantFactory implements JucatorFactory{
    @Override
    public Jucator creareJucator() {
        return new Atacant();
    }
}
