package s06_Prototype_generic;

public interface Prototype {
    Prototype clone();
}
