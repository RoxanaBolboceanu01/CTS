package Exemplu1Builder_tema;

public interface BurgerBuilder {
    void buildTipChifla();
    void buildCarne();
    void buildSos();
    void buildLegume();
    void buildCondimente();

    public Burger getBurger();
}
