package s06_Builder;

public interface CarBuilder {
    //elementele de build pentru elementele comune
    public void buildChassis();
    public void buildWheels();
    public void buildInteriorDesign();
    public void buildEngine();

    //!! get neaparat
    public Car getCar(); //!!! returnam Car, nu particularizam !!
}
