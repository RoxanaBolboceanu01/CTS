package s06_Builder;

public class Main {

    public static void main(String[] args) {

        //ElectricCar
	    CarBuilder builder = new ElectricCarBuilder();
        CarEngineer inginer = new CarEngineer(builder);
        inginer.buildCar();
        Car masina = inginer.getCar();
        System.out.println(masina.showDetails());

        //RegularCar
        builder = new RegularCarBuilder();
        inginer = new CarEngineer(builder);
        inginer.buildCar();
        masina = inginer.getCar();
        System.out.println(masina.showDetails());
    }
}
