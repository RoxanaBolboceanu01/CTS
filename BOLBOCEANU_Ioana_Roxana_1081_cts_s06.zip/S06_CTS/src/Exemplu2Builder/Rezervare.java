package Exemplu2Builder;

public interface Rezervare {
    void setNume(String nume);
    void setNrPersoane(int nrPersoane);
    public String showDetails();
}
