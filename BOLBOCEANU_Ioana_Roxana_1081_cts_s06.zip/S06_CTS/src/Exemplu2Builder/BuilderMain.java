package Exemplu2Builder;

public class BuilderMain {
    public static void main(String[] args) {
    /*Atunci când un client face o rezervare poate alege una din următoarele opțiuni: așezare la geam,
scaune ergonomice, decorarea mesei, muzica ambientala personalizata, gen muzica. În cazul în
care clientul nu specifică vreun element dintre acestea, este setat pe false. Să se implementeze
modulul care permite crearea de obiecte de tip rezervare cu aceste opțiuni extra*/

        RezervareBuilder builder = new RezervareClientBuilder();
        SistemRezervari rezervari = new SistemRezervari(builder);
        rezervari.build();
        Rezervare client1 = rezervari.getRezervare();
        client1.showDetails();

        System.out.println(client1.showDetails());
    }
}
