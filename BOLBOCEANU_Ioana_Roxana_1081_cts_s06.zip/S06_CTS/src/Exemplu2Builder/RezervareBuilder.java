package Exemplu2Builder;

public interface RezervareBuilder {
    void buildNume();
    void buildNrPersoane();

    public Rezervare getRezervare();
}
