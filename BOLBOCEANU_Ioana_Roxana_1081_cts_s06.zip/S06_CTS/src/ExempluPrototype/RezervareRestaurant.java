package ExempluPrototype;

public class RezervareRestaurant implements Rezervare {
    private String nume;
    private String prenume;
    private String varsta;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setVarsta(String varsta) {
        this.varsta = varsta;
    }

    public void genereazaRezervare() {
        System.out.println("Client: " + "Nume : " +  nume + " | Prenume : " + prenume + " | Varsta: " + varsta + " ani");
    }
    @Override
    public Rezervare clone() throws CloneNotSupportedException {
        return (RezervareRestaurant)super.clone();
    }
}
