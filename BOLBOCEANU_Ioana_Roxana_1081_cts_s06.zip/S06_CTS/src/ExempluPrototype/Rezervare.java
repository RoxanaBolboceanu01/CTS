package ExempluPrototype;

public interface Rezervare extends Cloneable{
    void setNume(String nume);
    void setPrenume(String prenume);
    void setVarsta(String varsta);

    void genereazaRezervare();
    public Rezervare clone() throws CloneNotSupportedException;
}
