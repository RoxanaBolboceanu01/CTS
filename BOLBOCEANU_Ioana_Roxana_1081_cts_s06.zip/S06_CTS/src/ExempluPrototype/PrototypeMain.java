package ExempluPrototype;

public class PrototypeMain {
    public static void main(String[] args) {

        GeneratorRezervare generatorRezervare = new GeneratorRezervare();
        Rezervare rezervare = generatorRezervare.genereazaRezervare("client1","Popescu","Ion","24");
    }
}