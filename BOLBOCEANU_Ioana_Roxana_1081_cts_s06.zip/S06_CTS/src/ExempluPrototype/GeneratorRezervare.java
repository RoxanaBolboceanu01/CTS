package ExempluPrototype;

import java.util.HashMap;
import java.util.Map;

public class GeneratorRezervare {

    Map<String,Rezervare> rezervari = new HashMap<>();

    GeneratorRezervare() {
        rezervari.put("client1", new RezervareRestaurant());
    }

    public Rezervare genereazaRezervare(String client, String nume, String prenume, String varsta) {
        try {
            Rezervare rezervare = rezervari.get(client).clone();
            rezervare.setNume(nume);
            rezervare.setPrenume(prenume);
            rezervare.setVarsta(varsta);
            rezervare.genereazaRezervare();
            return rezervare;
        } catch (CloneNotSupportedException e) {
            System.out.println("Error " + e.getMessage());
            return null;

        }
    }
}
