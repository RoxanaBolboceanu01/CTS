import s06_Prototype_concrete.Report;
import s06_Prototype_concrete.ReportGenerator;
import s06_Prototype_generic.Client;
import s06_Prototype_generic.Prototype;


public class PrototypeMain {

    public static void main(String[] args) {
        //pentru minimizarea costurilor
        Client client = new Client();
        Prototype prototypeA = client.create("A");
        Prototype prototypeB = client.create("B");


        ReportGenerator reportGenerator = new ReportGenerator();
        Report salesReport = reportGenerator.generateReport("sales", "Sales data", "PDF");
        //Report marketingReport = reportGenerator.generateReport("marketing", "Marketing data", "Excel");

    }
}
