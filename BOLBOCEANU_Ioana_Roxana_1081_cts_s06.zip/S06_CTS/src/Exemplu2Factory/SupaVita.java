package Exemplu2Factory;

public class SupaVita implements Supa{
    public SupaVita()
    {
        System.out.println("Supa de vita");
    }
}
