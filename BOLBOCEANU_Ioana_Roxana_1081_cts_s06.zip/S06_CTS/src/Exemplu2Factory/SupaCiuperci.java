package Exemplu2Factory;

public class SupaCiuperci implements Supa{
    public SupaCiuperci() {
        System.out.println("Supa ciuperci");
    }
}
