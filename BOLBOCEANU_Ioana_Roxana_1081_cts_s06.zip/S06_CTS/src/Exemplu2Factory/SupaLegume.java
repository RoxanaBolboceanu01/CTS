package Exemplu2Factory;

public class SupaLegume  implements Supa {
    public SupaLegume() {
        System.out.println("Supa legume");
    }
}
