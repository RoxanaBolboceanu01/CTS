package Exemplu2Factory;

public class SupaVitaFactory implements SupaFactory{
    @Override
    public Supa creareSupa() {
        return new SupaVita();
    }
}
