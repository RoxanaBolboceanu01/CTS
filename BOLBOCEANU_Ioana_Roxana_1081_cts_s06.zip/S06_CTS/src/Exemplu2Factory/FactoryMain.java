package Exemplu2Factory;

public class FactoryMain {
    /*. Restaurantul servește mai multe tipuri de supe: supă de legume, supă de ciuperci, supă de vită,
etc. Să se implementeze modulul care permite realizarea de obiecte din familia supelor. Modulul
trebuie realizat, astfel încât pentru adăugări de noi tipuri de supă să nu fie necesare modificări în
codul existent. */
    public static void main(String[] args) {

        SupaFactory supa1, supa2, supa3;

        System.out.println("---------------SUPA CIUPERCI---------------");

        supa1 = new SupaCiuperciFactory();
        supa1.creareSupa();

        System.out.println("---------------SUPA LEGUME---------------");

        supa2 = new SupaLegumeFactory();
        supa2.creareSupa();

        System.out.println("---------------SUPA VITA---------------");

        supa3 = new SupaVitaFactory();
        supa3.creareSupa();
    }
}
