package Exemplu2Factory;

public class SupaCiuperciFactory implements SupaFactory{
    @Override
    public Supa creareSupa() {
        return new SupaCiuperci();
    }
}
