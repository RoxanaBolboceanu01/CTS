package Exemplu2Factory;

public class SupaLegumeFactory implements SupaFactory{
    @Override
    public Supa creareSupa() {
        return new SupaLegume();
    }
}
