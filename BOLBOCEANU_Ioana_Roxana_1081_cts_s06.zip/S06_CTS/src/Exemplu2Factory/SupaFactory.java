package Exemplu2Factory;

public interface SupaFactory {
    Supa creareSupa();
}
