package Exemplu2Factory;

public interface Supa {
}
